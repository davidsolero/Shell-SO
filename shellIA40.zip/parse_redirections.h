#ifndef _PARSE_REDIRECTIONS_H
#define _PARSE_REDIRECTIONS_H

#include "string.h"
#include <stdio.h>

void parse_redirections(char **args, char **file_in, char **file_out);

#endif